public class CurrentDateTime {

	public static void main(String[] args) {

		java.util.Date date = new java.util.Date();
		
		System.out.println(date);

	}

}
