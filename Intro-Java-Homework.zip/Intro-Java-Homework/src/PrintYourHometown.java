
public class PrintYourHometown {

	public static void main(String[] args) {
		
		System.out.println("My hometown is Sofia.");
		
	}

}
