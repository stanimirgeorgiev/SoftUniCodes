#!/bin/bash
java -cp IntroJavaHomework.jar CurrentDateTime
java -cp IntroJavaHomework.jar PrintYourHometown
java -cp IntroJavaHomework.jar SumTwoNumbers